#!/bin/bash
echo "Starting lightweight submission..."
mkdir -p tmp
# Copy the pre-bundled submission.npy to the target location
cp submission.npy tmp/submission.npy
echo "Done. Copied local result to tmp/submission.npy"
exit 0
